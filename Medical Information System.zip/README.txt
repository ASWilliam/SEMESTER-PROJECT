Name: Asare Solomon William
Index number: UEB3259122
Class: Information Technology class B